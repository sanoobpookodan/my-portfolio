import { __esmMin as e } from "./rolldown-runtime.DSjM2LRs.mjs";
import {
  init_jsx_runtime as t,
  init_npm_react_18_2 as n,
  p as r,
  u as i,
  x as a,
} from "./react.CL8SE-Jx.mjs";
import {
  init_framer_motion_5EXT2AMG as o,
  motion as s,
} from "./motion.CbTbuOc9.mjs";
import { Link as c, init_framer_TLIAXGT6 as l } from "./framer.tQbOOGJb.mjs";
var u,
  d,
  f,
  p,
  m,
  h,
  g,
  _,
  v,
  y,
  b,
  x,
  S,
  C,
  w,
  T,
  E,
  D,
  O,
  k,
  A,
  j,
  M,
  N,
  P,
  F,
  I,
  L,
  R,
  z,
  B,
  V,
  H,
  U = e(() => {
    t(),
      l(),
      o(),
      n(),
      (u = i(a, {
        children: [
          r(`h2`, { children: `Project Description` }),
          r(`p`, {
            children: `Choose My Fresh is a growing grocery delivery platform offering fresh vegetables, fruits, and meat directly from local sources. As part of their digital expansion, they needed a mobile app revamp to improve user engagement, simplify product browsing, and boost order conversions.`,
          }),
        ],
      })),
      (d = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `Challenge` }) }),
          r(`p`, {
            children: `The previous app interface lacked clarity and was difficult to navigate. Users often struggled with product discovery, filtering options, and checkout — leading to drop-offs and low repeat purchases.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Ways of Working` }) }),
          r(`p`, {
            children: `I collaborated with stakeholders and developers to reimagine the app with a user-first approach — from research and wireframes to final visuals and prototypes.`,
          }),
        ],
      })),
      (f = i(a, {
        children: [
          r(`h2`, { children: `Process` }),
          r(`p`, {
            children: `A step-by-step journey from research to delivery — focusing on solving user pain points, refining the user flow, and delivering a seamless grocery shopping experience. 4o`,
          }),
          r(`p`, { children: r(`br`, { className: `trailing-break` }) }),
        ],
      })),
      (p = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Research & Planning` }),
          }),
          r(`p`, {
            children: `Conducted competitor benchmarking and user interviews to understand key pain points in the online grocery shopping flow. Mapped out common user journeys to define essential features like quick filters, wishlist, and one-tap reorder.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Design & Prototyping` }),
          }),
          r(`p`, {
            children: `Designed low and high-fidelity wireframes in Figma. Created interactive prototypes and iterated the flows based on usability feedback. Focused on a clean, fresh visual language aligned with the brand.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Development & Implementation` }),
          }),
          r(`p`, {
            children: `Worked closely with the dev team to ensure the design vision was translated correctly. Prioritized features like express delivery tagging, real-time inventory sync, and a simplified cart and checkout experience.`,
          }),
        ],
      })),
      (m = i(a, {
        children: [
          r(`h2`, { children: `Solution` }),
          r(`p`, {
            children: `The redesigned mobile app offers a smoother, more intuitive shopping journey from browsing to doorstep delivery.`,
          }),
        ],
      })),
      (h = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `Smart Browsing` }) }),
          r(`p`, {
            children: `Quick filters, popular categories, and dynamic search suggestions streamline product discovery.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Easy Ordering` }) }),
          r(`p`, {
            children: `One-tap repeat orders, saved delivery addresses, and real-time stock updates.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Personalized Experience` }),
          }),
          r(`p`, {
            children: `User-specific suggestions based on past orders and seasonal buying patterns.`,
          }),
        ],
      })),
      (g = i(a, {
        children: [
          r(`h2`, { children: `Results` }),
          r(`p`, {
            children: `Key outcomes that reflect improved usability, increased conversions, and stronger customer loyalty after the app redesign.`,
          }),
        ],
      })),
      (_ = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `User Engagement` }) }),
          i(`p`, {
            children: [
              `Session duration increased by `,
              r(`strong`, { children: `30%` }),
              ` with improved navigation and product visibility.`,
            ],
          }),
          r(`p`, { children: r(`strong`, { children: `Conversion Rates` }) }),
          i(`p`, {
            children: [
              r(`strong`, { children: `18%` }),
              ` boost in order completion rate thanks to faster checkout and reorder options.`,
            ],
          }),
          r(`p`, { children: r(`strong`, { children: `Customer Retention` }) }),
          r(`p`, {
            children: `Notable rise in repeat purchases from weekly buyers, especially in metro areas.`,
          }),
        ],
      })),
      (v = i(a, {
        children: [
          r(`h2`, { children: `Project description` }),
          r(`p`, {
            children: `Al Hadi AE is a growing service-based business aiming to establish a strong digital presence in the UAE. They needed a clean, professional website that reflects their values, showcases services clearly, and builds trust with clients through intuitive design and modern visuals.`,
          }),
        ],
      })),
      (y = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `Challenge` }) }),
          r(`p`, {
            children: `The previous site lacked structure and professionalism. It didn’t reflect the brand’s credibility or make it easy for users to understand their offerings or get in touch quickly.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Ways of working` }) }),
          r(`p`, {
            children: `Collaborated closely with stakeholders to understand their vision and business goals. Applied a user-centered design approach to deliver a sleek, responsive website optimized for performance and clarity.`,
          }),
        ],
      })),
      (b = i(a, {
        children: [
          r(`h2`, { children: `Process` }),
          r(`p`, {
            children: `A step-by-step journey from strategy to final launch — prioritizing clarity, usability, and brand alignment.`,
          }),
        ],
      })),
      (x = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Research & Planning` }),
          }),
          r(`p`, {
            children: `Analyzed the target audience and studied competitor websites to define design direction and content flow.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Design & Prototyping` }),
          }),
          r(`p`, {
            children: `Created a minimal and elegant visual style with clear CTAs, informative layouts, and smooth navigation.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Development & Implementation` }),
          }),
          r(`p`, {
            children: `Delivered a responsive website in Framer that loads fast, scales well across devices, and is easy to maintain.`,
          }),
        ],
      })),
      (S = i(a, {
        children: [
          r(`h2`, { children: `Solution` }),
          r(`p`, {
            children: `The final website brings a balance of elegance and functionality — helping Al Hadi AE connect with clients effectively.`,
          }),
        ],
      })),
      (C = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, {
              children: `Clear Information Architecture`,
            }),
          }),
          r(`p`, {
            children: `Services, contact, and company info are easy to access with a clean navigation system.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Conversion-Focused Layout` }),
          }),
          r(`p`, {
            children: `Strategic call-to-action placements to increase inquiries and client engagement.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Mobile-Optimized` }) }),
          r(`p`, {
            children: `Fully responsive design offering smooth browsing across phones, tablets, and desktops.`,
          }),
        ],
      })),
      (w = i(a, {
        children: [
          r(`h2`, { children: `Results` }),
          r(`p`, {
            children: `A stronger online presence, increased credibility, and higher client engagement after the redesign.`,
          }),
        ],
      })),
      (T = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Improved Brand Presence` }),
          }),
          r(`p`, {
            children: `Visitors now perceive the company as more professional and trustworthy.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Increased Inquiries` }),
          }),
          r(`p`, {
            children: `Contact form submissions and calls grew by 22% in the first month after launch.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Faster Performance` }) }),
          r(`p`, {
            children: `Page load speed improved by over 40%, enhancing SEO and user experience.`,
          }),
          i(`p`, {
            children: [
              `click here :  `,
              r(c, {
                href: `https://alhadiae.com/`,
                motionChild: !0,
                nodeId: `HvA2icrab`,
                openInNewTab: !0,
                scopeId: `contentManagement`,
                smoothScroll: !1,
                children: r(s.a, { children: `https://alhadiae.com/` }),
              }),
            ],
          }),
        ],
      })),
      (E = i(a, {
        children: [
          r(`h2`, { children: `Project description` }),
          r(`p`, {
            children: `BRD Luxe is a premier dealership offering a curated collection of pre-owned luxury cars from world-renowned brands like BMW, Mercedes-Benz, Audi, and more. They needed a digital platform that mirrored their in-showroom experience — elegant, trustworthy, and easy to navigate.`,
          }),
        ],
      })),
      (D = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `Challenge` }) }),
          r(`p`, {
            children: `The brand lacked a strong online presence to match its premium identity. Users found it difficult to browse inventory, understand vehicle specs, and connect with the sales team digitally.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Ways of Working` }) }),
          r(`p`, {
            children: `Worked directly with the founders to define the digital tone and user experience. The focus was on clarity, luxury design aesthetics, and lead conversion strategies.`,
          }),
        ],
      })),
      (O = i(a, {
        children: [
          r(`h2`, { children: `Process` }),
          r(`p`, {
            children: `From brand research to launching a refined, responsive website with seamless inventory navigation.`,
          }),
        ],
      })),
      (k = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Research & Planning` }),
          }),
          r(`p`, {
            children: `Identified what luxury car buyers expect online — trust, detailed information, and visual sophistication.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Design & Prototyping` }),
          }),
          r(`p`, {
            children: `Designed a visually striking yet minimal UI, ensuring each vehicle listing felt exclusive and premium.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Development & Integration` }),
          }),
          r(`p`, {
            children: `Built using Framer with seamless contact forms, WhatsApp integration, and future-ready inventory modules.`,
          }),
        ],
      })),
      (A = i(a, {
        children: [
          r(`h2`, { children: `Solution` }),
          r(`p`, {
            children: `A responsive, visually polished website that turns browsing into a luxury discovery experience.`,
          }),
        ],
      })),
      (j = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Premium Inventory Showcase` }),
          }),
          r(`p`, {
            children: `High-quality imagery, car comparison options, and detailed specifications for informed decision-making.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Intuitive Browsing` }) }),
          r(`p`, {
            children: `Smart filtering and category-wise listings for an easy user journey.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Fast Connect` }) }),
          r(`p`, {
            children: `Quick inquiry buttons and mobile-optimized layout for direct engagement.`,
          }),
        ],
      })),
      (M = i(a, {
        children: [
          r(`h2`, { children: `Results` }),
          r(`p`, {
            children: `Elevating brand perception and increasing qualified leads with a seamless digital platform.`,
          }),
        ],
      })),
      (N = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Improved Engagement` }),
          }),
          r(`p`, {
            children: `Time spent on the site increased by 35% as users explored more listings.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Lead Conversion` }) }),
          r(`p`, {
            children: `The redesigned inquiry process led to a 20% increase in lead submissions.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Brand Alignment` }) }),
          r(`p`, {
            children: `The website now accurately reflects the premium nature of BRD Luxe’s offerings.`,
          }),
        ],
      })),
      (P = i(a, {
        children: [
          r(`h2`, { children: `Project description` }),
          r(`p`, {
            children: `Arayal Resorts is a luxury eco-resort nestled in the heart of Wayanad, Kerala. They offer a tranquil escape with nature-rich surroundings and high-end amenities. The resort needed a website that reflected its serene identity and made online bookings effortless for travelers.`,
          }),
        ],
      })),
      (F = i(a, {
        children: [
          r(`p`, { children: r(`strong`, { children: `Challenge` }) }),
          r(`p`, {
            children: `The existing website felt outdated and lacked a refined booking experience. Users struggled to explore amenities, check room availability, and make reservations without friction.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Ways of working` }) }),
          r(`p`, {
            children: `Collaborated with the resort’s marketing and management teams to restructure content, enhance usability, and align visuals with the brand’s nature-luxury fusion.`,
          }),
        ],
      })),
      (I = i(a, {
        children: [
          r(`h2`, { children: `Process` }),
          r(`blockquote`, {
            children: r(`p`, {
              children: `A thoughtful approach to creating an inviting and functional online experience for potential guests.`,
            }),
          }),
          r(`h4`, { children: r(`br`, { className: `trailing-break` }) }),
        ],
      })),
      (L = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Research & Planning` }),
          }),
          r(`p`, {
            children: `Explored top resort websites, analyzed user expectations, and mapped out the ideal booking journey.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Design & Prototyping` }),
          }),
          r(`p`, {
            children: `Designed a visual style combining luxury and nature, with intuitive navigation and immersive visuals.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Development & Integration` }),
          }),
          r(`p`, {
            children: `Built a fast, mobile-first interface with smooth room exploration and contact integration for quick inquiries.`,
          }),
        ],
      })),
      (R = i(a, {
        children: [
          r(`h2`, { children: `Solution` }),
          r(`p`, {
            children: `A visually rich and functional website that conveys the resort’s peaceful, luxurious atmosphere.`,
          }),
        ],
      })),
      (z = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Nature-Inspired Design` }),
          }),
          r(`p`, {
            children: `Elegant color schemes, ambient visuals, and spacious layouts reflect the resort’s natural vibe.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Streamlined Booking Flow` }),
          }),
          r(`p`, {
            children: `Simplified the room selection and inquiry process for higher conversion rates.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Mobile-Optimized` }) }),
          r(`p`, {
            children: `Designed for all devices to ensure users can book from anywhere, anytime.`,
          }),
        ],
      })),
      (B = i(a, {
        children: [
          r(`h2`, { children: `Results` }),
          r(`p`, {
            children: `A digital upgrade that reflects the resort’s charm and drives better booking engagement.`,
          }),
          r(`p`, { children: r(`br`, { className: `trailing-break` }) }),
        ],
      })),
      (V = i(a, {
        children: [
          r(`p`, {
            children: r(`strong`, { children: `Increased Reservations` }),
          }),
          r(`p`, {
            children: `The intuitive flow led to a 30% rise in online bookings within the first 2 months.`,
          }),
          r(`p`, {
            children: r(`strong`, { children: `Enhanced Brand Perception` }),
          }),
          r(`p`, {
            children: `Guests reported a better first impression, aligning with the resort's luxurious experience.`,
          }),
          r(`p`, { children: r(`strong`, { children: `Reduced Drop-Offs` }) }),
          r(`p`, {
            children: `Improved user experience led to lower bounce rates and higher interaction across all pages.`,
          }),
        ],
      })),
      (H = {
        exports: {
          richText21: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText30: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText2: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText10: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText1: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText8: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText3: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText15: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText25: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText20: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText7: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText4: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText22: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText11: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText19: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText12: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText16: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText14: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText17: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText31: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText18: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText6: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText5: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText29: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText27: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText26: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText13: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText24: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText28: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText9: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          richText23: {
            type: `variable`,
            annotations: { framerContractVersion: `1` },
          },
          __FramerMetadata__: { type: `variable` },
        },
      });
  });
U();
export {
  H as __FramerMetadata__,
  u as richText,
  d as richText1,
  b as richText10,
  x as richText11,
  S as richText12,
  C as richText13,
  w as richText14,
  T as richText15,
  E as richText16,
  D as richText17,
  O as richText18,
  k as richText19,
  f as richText2,
  A as richText20,
  j as richText21,
  M as richText22,
  N as richText23,
  P as richText24,
  F as richText25,
  I as richText26,
  L as richText27,
  R as richText28,
  z as richText29,
  p as richText3,
  B as richText30,
  V as richText31,
  m as richText4,
  h as richText5,
  g as richText6,
  _ as richText7,
  v as richText8,
  y as richText9,
};
//# sourceMappingURL=HvA2icrab-2.BAYq8eDg.mjs.map
