import { __esmMin as e } from "./rolldown-runtime.DSjM2LRs.mjs";
import {
  Y as t,
  ae as n,
  init_jsx_runtime as r,
  init_npm_react_18_2 as i,
  p as a,
  pe as o,
  re as s,
  se as c,
  u as l,
  x as u,
} from "./react.CL8SE-Jx.mjs";
import {
  LayoutGroup as d,
  MotionConfigContext as f,
  init_framer_motion_5EXT2AMG as p,
  motion as m,
} from "./motion.CbTbuOc9.mjs";
import {
  ControlType as h,
  Image2 as g,
  addFonts as _,
  addPropertyControls as v,
  cx as y,
  getLoadingLazyAtYPosition as b,
  init_framer_TLIAXGT6 as x,
  useComponentViewport as S,
  useLocaleInfo as C,
  useVariantState as w,
  withCSS as T,
  withFX as E,
} from "./framer.tQbOOGJb.mjs";
var D,
  O,
  k,
  A,
  j,
  M,
  N,
  P,
  F,
  I,
  L,
  R,
  z = e(() => {
    r(),
      x(),
      p(),
      i(),
      (D = E(m.div)),
      (O = `framer-Sund5`),
      (k = { rAsxcgzt5: `framer-v-13f0yac` }),
      (A = { bounce: 0.2, delay: 0, duration: 0.4, type: `spring` }),
      (j = (e) =>
        typeof e == `object` && e && typeof e.src == `string`
          ? e
          : typeof e == `string`
          ? { src: e }
          : void 0),
      (M = ({ value: e, children: t }) => {
        let n = s(f),
          r = e ?? n.transition,
          i = c(() => ({ ...n, transition: r }), [JSON.stringify(r)]);
        return a(f.Provider, { value: i, children: t });
      }),
      (N = m.create(u)),
      (P = ({ height: e, id: t, image: n, width: r, ...i }) => ({
        ...i,
        gqLaMlXqi: n ??
          i.gqLaMlXqi ?? {
            pixelHeight: 2e3,
            pixelWidth: 3200,
            src: `https://framerusercontent.com/images/F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg?scale-down-to=1024`,
            srcSet: `https://framerusercontent.com/images/F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg?scale-down-to=512 512w,https://framerusercontent.com/images/F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg?scale-down-to=1024 1024w,https://framerusercontent.com/images/F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg?scale-down-to=2048 2048w,https://framerusercontent.com/images/F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg 3200w`,
          },
      })),
      (F = (e, t) =>
        e.layoutDependency ? t.join(`-`) + e.layoutDependency : t.join(`-`)),
      (I = t(function (e, t) {
        let r = o(null),
          i = t ?? r,
          s = n(),
          { activeLocale: c, setLocale: u } = C(),
          f = S(),
          {
            style: p,
            className: h,
            layoutId: _,
            variant: v,
            gqLaMlXqi: x,
            ...T
          } = P(e),
          {
            baseVariant: E,
            classNames: I,
            clearLoadingGesture: L,
            gestureHandlers: R,
            gestureVariant: z,
            isLoading: B,
            setGestureState: V,
            setVariant: H,
            variants: U,
          } = w({
            defaultVariant: `rAsxcgzt5`,
            ref: i,
            variant: v,
            variantClassNames: k,
          }),
          W = F(e, U),
          G = [],
          K = y(O, ...G);
        return a(d, {
          id: _ ?? s,
          children: a(N, {
            animate: U,
            initial: !1,
            children: a(M, {
              value: A,
              children: l(m.div, {
                ...T,
                ...R,
                className: y(K, `framer-13f0yac`, h, I),
                "data-framer-name": `Variant 1`,
                layoutDependency: W,
                layoutId: `rAsxcgzt5`,
                ref: i,
                style: {
                  borderBottomLeftRadius: 18,
                  borderBottomRightRadius: 18,
                  borderTopLeftRadius: 18,
                  borderTopRightRadius: 18,
                  ...p,
                },
                children: [
                  a(D, {
                    __framer__spring: {
                      damping: 60,
                      delay: 0,
                      duration: 0.3,
                      ease: [0.44, 0, 0.56, 1],
                      mass: 1,
                      stiffness: 250,
                      type: `spring`,
                    },
                    __framer__styleTransformEffectEnabled: !0,
                    __framer__transformTargets: [
                      {
                        target: {
                          opacity: 1,
                          rotate: 0,
                          rotateX: 0,
                          rotateY: 0,
                          scale: 1,
                          skewX: 0,
                          skewY: 0,
                          x: 140,
                          y: -300,
                        },
                      },
                      {
                        target: {
                          opacity: 1,
                          rotate: 0,
                          rotateX: 0,
                          rotateY: 0,
                          scale: 1,
                          skewX: 0,
                          skewY: 0,
                          x: -120,
                          y: 120,
                        },
                      },
                    ],
                    __framer__transformTrigger: `onInView`,
                    __perspectiveFX: !1,
                    __smartComponentFX: !0,
                    __targetOpacity: 1,
                    className: `framer-aw4vkq`,
                    "data-framer-name": `Animated Border`,
                    layoutDependency: W,
                    layoutId: `L8m_hT3Qr`,
                    style: {
                      background: `linear-gradient(20deg, var(--token-b475daa1-123e-4ac4-9203-afa2fe736f56, rgb(11, 11, 11)) 49%, var(--token-ecafc256-809a-4d45-a91d-a2dbb56ff89e, rgb(221, 255, 0)) 100%)`,
                      transformPerspective: 1200,
                    },
                  }),
                  a(m.div, {
                    className: `framer-1nuwqgt`,
                    "data-framer-name": `Product showcase`,
                    layoutDependency: W,
                    layoutId: `L5SfrQqjz`,
                    style: {
                      backgroundColor: `var(--token-b475daa1-123e-4ac4-9203-afa2fe736f56, rgb(11, 11, 11))`,
                      borderBottomLeftRadius: 16,
                      borderBottomRightRadius: 16,
                      borderTopLeftRadius: 16,
                      borderTopRightRadius: 16,
                    },
                    children: a(g, {
                      background: {
                        alt: ``,
                        fit: `fill`,
                        loading: b(
                          (f?.y || 0) +
                            (2 +
                              ((f?.height || 568) -
                                4 -
                                ((f?.height || 568) - 4) * 1) /
                                2) +
                            0 +
                            0
                        ),
                        pixelHeight: 2e3,
                        pixelWidth: 3200,
                        sizes: `max(${f?.width || `100vw`} - 4px, 1px)`,
                        ...j(x),
                        positionX: `center`,
                        positionY: `center`,
                      },
                      className: `framer-v76g22`,
                      "data-framer-name": `Image`,
                      layoutDependency: W,
                      layoutId: `yKlUNKGkC`,
                    }),
                  }),
                ],
              }),
            }),
          }),
        });
      })),
      (L = [
        `@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }`,
        `.framer-Sund5.framer-a10y4b, .framer-Sund5 .framer-a10y4b { display: block; }`,
        `.framer-Sund5.framer-13f0yac { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 568px; justify-content: center; overflow: hidden; padding: 2px; position: relative; width: 860px; will-change: var(--framer-will-change-override, transform); }`,
        `.framer-Sund5 .framer-aw4vkq { bottom: -160px; flex: none; left: -160px; overflow: hidden; position: absolute; right: -160px; top: -160px; z-index: 1; }`,
        `.framer-Sund5 .framer-1nuwqgt { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 100%; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 1px; will-change: var(--framer-will-change-override, transform); z-index: 1; }`,
        `.framer-Sund5 .framer-v76g22 { flex: 1 0 0px; height: 1px; overflow: hidden; position: relative; width: 100%; }`,
      ]),
      (R = T(I, L, `framer-Sund5`)),
      (R.displayName = `Cards/ Image`),
      (R.defaultProps = { height: 568, width: 860 }),
      v(R, {
        gqLaMlXqi: {
          __defaultAssetReference: `data:framer/asset-reference,F72wip5ZrB7QvmSiwqFViRYw2Xk.jpg?originalFilename=PortfolioImage1.jpg&preferredSize=auto`,
          title: `Image`,
          type: h.ResponsiveImage,
        },
      }),
      _(R, [{ explicitInter: !0, fonts: [] }], {
        supportsExplicitInterCodegen: !0,
      });
  });
export { R as FramerCW2m0Dqge, z as init_CW2m0Dqge };
//# sourceMappingURL=CW2m0Dqge.Sj1bd6mI.mjs.map
